#!/bin/bash -u

get_centos_version(){
    echo "$(lsb_release -a | grep Release | awk '{print $2}' | cut -f1 -d".")"
}

SRC="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
LOGFILE="$SRC"/install.log
CONF_FILE="cluster_connectivity.conf"

RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'

generate_ccm_v2_command_file(){
    local CCM_EXECUTABLE_PATH="/etc/jumpgate/jumpgate-agent-commands.sh"
    local CCM_SYMLINK="/usr/sbin/jumpgate-agent"

    rm $CCM_EXECUTABLE_PATH &>/dev/null
    rm $CCM_SYMLINK &>/dev/null

    echo '
        get_centos_version(){
            echo "$(lsb_release -a | grep Release | awk '"'"'{print $2}'"'"' | cut -f1 -d".")"
        }

        print_status_centos6(){
            service jumpgate-agent status
        }

        print_status_centos7(){
            local command_output_string=$(systemctl status jumpgate-agent.service | grep Active)
            local jumpgate_agent_running="Jumpgate Agent is running"
            local jumpgate_agent_not_running="Jumpgate Agent is not running"
            local active_string="Active: active (running)"
            local failed_string="Active: inactive (dead)"
            if [[ "$command_output_string" == *"$active_string"* ]]; then
                echo "${command_output_string/"$active_string"/$jumpgate_agent_running}"
            elif [[ "$command_output_string" == *"$failed_string"* ]]; then
                echo "${command_output_string/"$failed_string"/$jumpgate_agent_not_running}"
            else
                echo $command_output_string
            fi
        }

        case "${1:-}" in
        start)
            echo -e "   Starting Jumpgate Agent..."
            if [[ $(get_centos_version) -ge 7 ]]; then
                systemctl start jumpgate-agent.service
                sleep 1
                print_status_centos7
            else
                service jumpgate-agent start
                sleep 1
                print_status_centos6
            fi
            ;;
        stop)
            echo -e "   Stopping Jumpgate Agent..."
            if [[ $(get_centos_version) -ge 7 ]]; then
                systemctl stop jumpgate-agent.service
                sleep 1
                print_status_centos7
            else
                service jumpgate-agent stop
                sleep 1
                print_status_centos6
            fi
            ;;
        status)
            if [[ $(get_centos_version) -ge 7 ]]; then
                print_status_centos7
            else
                print_status_centos6
            fi
            ;;
        restart)
            echo -e "   Restarting Jumpgate Agent..."
            if [[ $(get_centos_version) -ge 7 ]]; then
                systemctl restart jumpgate-agent.service
                sleep 1
                print_status_centos7
            else
                service jumpgate-agent restart
                sleep 1
                print_status_centos6
            fi
            ;;
        *)
        echo "Usage:
        start   : jumpgate-agent start
        stop    : jumpgate-agent stop
        status  : jumpgate-agent status
        restart : jumpgate-agent restart"
        ;;
        esac' >> ${CCM_EXECUTABLE_PATH}

    chmod +x $CCM_EXECUTABLE_PATH
    ln -sv $CCM_EXECUTABLE_PATH $CCM_SYMLINK &>/dev/null
}

generate_timestamping_logs_file(){
    if [[ $(get_centos_version) -lt 7 ]]; then
      echo '
          #!/bin/bash
          while read line ; do
              echo `date`" reverse-tunnel.sh: ${line}" &>> /var/log/messages
          done' > /cdp/bin/prepend-timestamp.sh

      chmod +x /cdp/bin/prepend-timestamp.sh
      fi
}

logit() {
    if [ -f "$LOGFILE" ]; then
      chmod 640 ${LOGFILE}
    fi
    local m_time=`date "+%F %T"`
    echo "[${USER}][${m_time}] - ${*}"
    echo "[${USER}][${m_time}] - ${*}" >> ${LOGFILE}
}

run_command_with_exit() {
    local CMD=${*}
    local TMP=$(mktemp)
    eval ${CMD} > ${TMP} 2>&1
    local EXITCODE=$?
    local OUTPUT=$(cat ${TMP})
    rm ${TMP}
    if [ $EXITCODE -eq 0 ] ; then
        logit "${CMD} succeeded with exit code ${EXITCODE}"
        logit "${OUTPUT}"
    else
        echo "${OUTPUT}"
        logit "${CMD} failed with exit code $EXITCODE. The script will exit."
        logit "${OUTPUT}"
        exit $EXITCODE
    fi
}

run_command_with_retry(){
    local retries=10
    local count=0
    local CMD=${*}
    while true; do
        local TMP=$(mktemp)
        eval ${CMD} > ${TMP} 2>&1
        local EXITCODE=$?
        local OUTPUT=$(cat ${TMP})
        rm ${TMP}
        if [ $EXITCODE -eq 0 ] ; then
            logit "${CMD} succeeded with exit code ${EXITCODE}"
            logit "${OUTPUT}"
            return 0
        fi
        wait=$((2 ** $count))
        count=$(($count + 1))
        if [ $count -lt $retries ]; then
            logit "${CMD} failed with exit code $EXITCODE."
            logit "${OUTPUT}."
            logit "Retry $count/$retries exited $EXITCODE, retrying in $wait seconds..."
            sleep $wait
        else
            logit "Retry $count/$retries exited $EXITCODE, no more retries left."
            exit $EXITCODE
        fi
    done
    return 0
}

hdp_setup_cdp_default_topology() {
    local CLUSTER_TYPE=$1
    echo ""
    echo "=================================================================================================================================="
    logit "Classic clusters will now setup cdp_default topology to enable communication through Knox."
    echo ""

    read -p "Enter Ambari URL  (http(s)://host:[port])  :"  AMBARI_URL
    if [[ -z $AMBARI_URL ]]; then
        logit "Ambari url must be non-empty."
        exit 1
    fi

    read -p "Enter Ambari Username                      :"  AMBARI_USERNAME
    if [[ -z $AMBARI_USERNAME ]]; then
        logit "Ambari username must be non-empty."
        exit 1
    fi

    read -s -p "Enter Ambari Password                      :"  AMBARI_PASSWORD
    if [[ -z $AMBARI_PASSWORD ]]; then
        logit "Ambari password must be non-empty."
        exit 1
    fi

    echo ""
    echo ""
    python setup_cdp_default_topology.py ${CLUSTER_TYPE} ${AMBARI_URL} ${AMBARI_USERNAME} ${AMBARI_PASSWORD}
    setup_cdp_default_topology_exit_code=$?
    if [ $setup_cdp_default_topology_exit_code -ne 0 ]; then
         exit 1
    fi
    echo "=================================================================================================================================="
    echo ""
}

generate_topology() {

  local CLUSTER_TYPE=$1
  local CCM_TUNNEL_ROLE=$2

  local KNOX_CLI_PATH="/usr/hdp/current/knox-server/bin/knoxcli.sh"

  if [ $CLUSTER_TYPE == "HDP" ]; then
      hdp_setup_cdp_default_topology  ${CLUSTER_TYPE}
      if [ -d "$KNOX_CLI_PATH" ]; then
        local topology_deployed="false"
        for i in {1..10}
        do
          local OUTPUT=$(/bin/bash "$KNOX_CLI_PATH" validate-topology --cluster cdp_default | tail -1)
          if [ "$OUTPUT" != "Topology file validated successfully" ]; then
              logit "Waiting for cdp_default topology to be deployed..."
              sleep 5
              continue
          else
            topology_deployed="true"
            break
          fi
        done
        if [ "$topology_deployed" == "true" ]; then
          logit "cdp_default topology deployed!"
        else
          logit "cdp_default topology deployment failed. Please check Knox logs!"
          exit -1
        fi
        fi
  fi
}

move_install_log(){
    local date=$(date +%Y-%m-%d-%H-%M-%S)
    local backup_log_file="install.log".${date}
    if [ -f "${SRC}/install.log" ]; then
        mv ${SRC}/install.log ${SRC}/${backup_log_file}
    fi
}

usage(){
    printf ""
    printf "\nThis script configures SSH Tunnel for a Service."
    printf "\nThis script assumes you have bash installed."
    printf "\nThis script assumes you have installed ccm-autossh-client."
    printf "\nUsage:"
    printf "\n\tbash install.sh #Configures tunnel for a cloudera manager\n"
    printf "\n"
    printf ""

}
check_root(){
    if [[ $EUID -ne 0 ]]; then
    logit "This script must be run as root"
    exit 1
    fi
}

does_agent_exist(){
  local active=0
  local stop_command=""
  if [[ $(get_centos_version) -ge 7 ]]; then
    stop_command="jumpgate-agent stop"
    if (systemctl -q is-active jumpgate-agent.service) then
      active=1
    fi
  else
    stop_command="service jumpgate-agent stop"
    if [[ "$(service jumpgate-agent status)" == "Active" ]]; then
      active=1
    fi
  fi
  if [[ ${active} -eq 1 ]]; then
    echo "=================================================================================================================================="
    echo "We have detected an active agent is running on this machine. This might mean that the cluster is already registered."
    echo "Please verify if you have a registered cluster already."
    echo -e "If this is a new registration, stop the agent by running '${GREEN}${stop_command}${NC}' and then re-run install.sh."
    echo -e "${RED}NOTE: If the agent is stopped for a registered cluster, existing communication to this cluster from CDP will fail.${NC}"
    echo "=================================================================================================================================="
    exit;
    exit 1
  fi
}

create_jumpgate_directory(){
    mkdir -p /etc/jumpgate
}

execute_ccm_v2_init_flow() {
    local CONF_FILE=$1
    local TOML_FILE="/etc/jumpgate/config.toml"
    local CCMV2_PACKAGE_NAME="rpm -q jumpgate-agent-centos6"

    if [[ $(get_centos_version) -ge 7 ]]; then
      CCMV2_PACKAGE_NAME="rpm -q jumpgate-agent"
    fi

    create_jumpgate_directory
    generate_ccm_v2_command_file

    logit "Checking jumpgate-agent package ..."
    run_command_with_exit "${CCMV2_PACKAGE_NAME}"

    logit "Setting up Inverting proxy agent ... see ${LOGFILE} for details"
    . ${CONF_FILE}

    logit "Checking ${CONF_FILE} for values."
    if [[ -z $KEY_ID || -z $ACCOUNT_ID || -z $RELAY_SERVER || -z $BACKEND_ID || -z $CCM_TUNNEL_ROLE || -z $CCM_TUNNEL_SERVICE_PORT || -z $CLUSTER_TYPE || -z $IV || -z $RELAY_SERVER_CERTIFICATE || -z $IP_AGENT_CERTIFICATE || -z $IP_AGENT_PRIVATE_KEY || -z $ONE_WAY_TLS ]]; then
        logit "One of the variables in ${CONF_FILE} not defined."
        exit 1
    fi

    if [ $ONE_WAY_TLS == true ]; then
      if [[ -z $IP_AGENT_ACCESS_KEY || -z $ACCESS_KEY_ID || -z $ENVIRONMENT_CRN ]]; then
        logit "One of the variables for one way tls authentication in ${CONF_FILE} not defined."
        exit 1
      fi
    fi

    does_agent_exist
    if [ $INSTALLATION_TYPE != "UPGRADE" ]; then
      generate_topology ${CLUSTER_TYPE} ${CCM_TUNNEL_ROLE}
    fi


    logit "Setting up inverting proxy agent for ${KEY_ID}"
    logit "Using Inverting Proxy Host with ${RELAY_SERVER}"

    local relayServer="https://${RELAY_SERVER}/"
    local HEX_KEY_ID=$(od -A n -t x1 -N 16 <<< ${KEY_ID##*:} | tr -dc '[:xdigit:]')

    if [ $ONE_WAY_TLS == true ]; then
      cat > ${TOML_FILE} <<EOF
[agent]
relayServer = "${relayServer}"
relayServerCertificate = """$(cat $RELAY_SERVER_CERTIFICATE | base64 -d)"""
backendId = "${BACKEND_ID}"
accessKeyId = "${ACCESS_KEY_ID}"
environmentCrn = "${ENVIRONMENT_CRN}"
accessKey = """$(cat $IP_AGENT_ACCESS_KEY | openssl enc -aes-128-cbc -d -A -a -K ${HEX_KEY_ID} -iv ${IV})"""
EOF
    else
      cat > ${TOML_FILE} <<EOF
[agent]
relayServer = "${relayServer}"
relayServerCertificate = """$(cat $RELAY_SERVER_CERTIFICATE | base64 -d)"""
backendId = "${BACKEND_ID}"
clientAuthenticationCertificate = """$(cat $IP_AGENT_CERTIFICATE | base64 -d)"""
clientAuthenticationKey = """$(cat $IP_AGENT_PRIVATE_KEY | openssl enc -aes-128-cbc -d -A -a -K ${HEX_KEY_ID} -iv ${IV})"""
EOF
    fi

    run_command_with_exit "jumpgate-agent restart"

    echo "=========================================================================================="
    echo -e "${GREEN}Agent for ${RELAY_SERVER} is started successfully.${NC}"
    echo "Run 'jumpgate-agent status' for status"
    echo "Run 'tail -f /var/log/jumpgate/out.log' for output logs."
    echo "Run 'tail -f /var/log/jumpgate/access.log' for access logs."
    echo "=========================================================================================="
}

# --------------
check_root
if [[ $# -eq 0 ]] ; then
    CONFIG_FILE=${CONF_FILE}

    if test -f ${CONFIG_FILE} ; then
        . ${CONFIG_FILE}
    else
        logit "${CONFIG_FILE} not found, exiting."
        exit 1
    fi

    execute_ccm_v2_init_flow ${CONFIG_FILE}
else
    move_install_log
    case "$1" in
        -h | --help )
                usage
                exit
                ;;
        *)
            usage
            exit 1
            ;;
    esac
fi